// Import the express module
const express = require('express');

// Create an express application
const app = express();

app.use(express.json());

// Middleware to enable CORS (Cross Origin Resource Sharing)
app.use((req, res, next) => {
    // Allow any domain to access this API
    res.header('Access-Control-Allow-Origin', '*');
    // Allow headers for Origin, X-Requested-With, Content-Type, Accept
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});

// POST endpoint to calculate monthly mortgage payment
app.post('/mortgage', (req, res) => {
    const {principal, rate, term} = req.body;
    const monthlyRate = rate / 100 / 12;
    const numberOfPayments = term * 12;
    const denominator = Math.pow(1 + monthlyRate, numberOfPayments) - 1;
    const monthlyPayment = principal * (monthlyRate + (monthlyRate / denominator));
    // Send back the result with a 200 status code
    res.status(200).json({monthlyPayment});
});

// POST endpoint to calculate total interest
app.post('/interest', (req, res) => {
    const {principal, rate, term} = req.body;
    const totalInterest = (principal * rate * term) / 100;
    // Send back the result with a 200 status code
    res.status(200).json({totalInterest});
});

// POST endpoint to calculate home equity
app.post('/equity', (req, res) => {
    const {homeValue, loanBalance} = req.body;
    const homeEquity = homeValue - loanBalance;
    // Send back the result with a 200 status code
    res.status(200).json({homeEquity});
});

// POST endpoint to calculate return on investment (ROI)
app.post('/roi', (req, res) => {
    const {gain, cost} = req.body;
    const roi = ((gain - cost) / cost) * 100;
    // Send back the result with a 200 status code
    res.status(200).json({roi});
});

// POST endpoint to calculate annual depreciation
app.post('/depreciation', (req, res) => {
    const {initialCost, salvageValue, usefulLife} = req.body;
    const annualDepreciation = (initialCost - salvageValue) / usefulLife;
    // Send back the result with a 200 status code
    res.status(200).json({annualDepreciation});
});

// Make the server listen on port 3000
app.listen(3000, () => {
    console.log('Server is running at http://localhost:3000');
});
