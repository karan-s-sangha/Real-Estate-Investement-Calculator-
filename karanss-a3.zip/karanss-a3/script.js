// Declare an async function 
async function calculate(metric) {
    // Use the 'document.getElementById' method to get the value of the input elements
    // Parse the values as floating point numbers using 'parseFloat'
    const principal = parseFloat(document.getElementById('principal').value);
    const rate = parseFloat(document.getElementById('rate').value);
    const term = parseFloat(document.getElementById('term').value);
    const homeValue = parseFloat(document.getElementById('homeValue').value);
    const loanBalance = parseFloat(document.getElementById('loanBalance').value);
    const gain = parseFloat(document.getElementById('gain').value);
    const cost = parseFloat(document.getElementById('cost').value);
    const initialCost = parseFloat(document.getElementById('initialCost').value);
    const salvageValue = parseFloat(document.getElementById('salvageValue').value);
    const usefulLife = parseFloat(document.getElementById('usefulLife').value);

    // Make a POST request to the local server with the 'fetch' function
    const response = await fetch(`http://localhost:3000/${metric}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        // Convert the input values to a JSON string to include in the request body
        body: JSON.stringify({ principal, rate, term, homeValue, loanBalance, gain, cost, initialCost, salvageValue, usefulLife }),
    });

    const data = await response.json();

    // Get the first key from the returned JSON object
    const resultKey = Object.keys(data)[0];

    // Use the 'getElementById' method to find the element where the result will be displayed
    // Set the 'textContent' property of this element to the calculation result
    document.getElementById(`${metric}Result`).textContent = data[resultKey];
}
